#include <stdio.h>
//declaracion de funciones
float costos(int cantidad, float precio);
float ITBMS(float subtotal);
float descuento(float subtotal);
float total(float subtotal, float itbms, float descuento);

int main () {
	char producto1 [30], producto2 [30], producto3 [30];
	int cantidad1, cantidad2, cantidad3;
	float precio1, precio2, precio3;
	float costo1, costo2, costo3;
	float subtotal;
	float itbms;
	float descuentos;
	float Totales;
	
	printf("Ingrese producto 1: ");
	scanf("%s", producto1);
	printf("Cantidad: ");
	scanf("%d", &cantidad1);
	printf("Precio: ");
	scanf("%f", &precio1);
	
	printf("Ingrese producto 2: ");
	scanf("%s", producto2);
	printf("Cantidad: ");
	scanf("%d", &cantidad2);
	printf("Precio: ");
	scanf("%f", &precio2);
	
	printf("Ingrese producto 3: ");
	scanf("%s", producto3);
	printf("Cantidad: ");
	scanf("%d", &cantidad3);
	printf("Precio: ");
	scanf("%f", &precio3);
	
	//operaciones
	costo1 = costos(cantidad1, precio1);
	costo2 = costos(cantidad2, precio2);
	costo3 = costos(cantidad3, precio3);
	
	subtotal = costo1 + costo2 + costo3;
	itbms = ITBMS(subtotal);
	descuentos = descuento(subtotal);
	Totales = total(subtotal, itbms, descuentos);
	
	printf("\nSubtotal: %.2f", subtotal);
	printf("\nITBMS: %.2f", itbms);
	printf("\nDescuento: %.2f", descuentos);
	printf("\nTotal: %.2f", Totales);
	
	return 0;
}
// aplicacion de las funciones (use float porque estoy trabajando con decimales)
float costos(int cantidad, float precio) {
	return cantidad * precio;
}
float ITBMS(float subtotal) {
	return subtotal * 0.07; // 7%
}
float descuento (float subtotal) {
	return subtotal * 0.10; // 10%
}
float total (float subtotal, float itbms, float descuento) {
	return subtotal + itbms - descuento;
}
