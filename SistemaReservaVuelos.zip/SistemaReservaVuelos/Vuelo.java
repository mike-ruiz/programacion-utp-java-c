// Representa un vuelo y administra los asientos disponibles.
public class Vuelo {
    // Datos generales del viaje.
    private final String codigo;
    private final String origen;
    private final String destino;
    private final String fecha;
    private final String hora;
    private final double precio;
    private final Asiento[] asientos;

    public Vuelo(String codigo, String origen, String destino, String fecha,
                 String hora, double precio, int cantidadAsientos) {
        // this distingue los atributos de la clase de los parametros recibidos.
        this.codigo = codigo;
        this.origen = origen;
        this.destino = destino;
        this.fecha = fecha;
        this.hora = hora;
        this.precio = precio;
        this.asientos = new Asiento[cantidadAsientos];

        // Crea un objeto Asiento por cada posicion y asigna numeros consecutivos.
        for (int i = 0; i < asientos.length; i++) {
            asientos[i] = new Asiento(i + 1);
        }
    }

    public String getCodigo() {
        return codigo;
    }

    public String getOrigen() {
        return origen;
    }

    public String getDestino() {
        return destino;
    }

    public String getFecha() {
        return fecha;
    }

    public String getHora() {
        return hora;
    }

    public double getPrecio() {
        return precio;
    }

    public void mostrarInformacion() {
        System.out.printf("%s | %s - %s | %s %s | $%.2f%n",
                codigo, origen, destino, fecha, hora, precio);
    }

    public void mostrarAsientos() {
        System.out.println("Asientos del vuelo " + codigo + ":");
        // La sintaxis for-each recorre cada asiento sin usar un indice.
        for (Asiento asiento : asientos) {
            String estado = asiento.estaDisponible() ? "Disponible" : "Ocupado";
            System.out.printf("  %d - %s%n", asiento.getNumero(), estado);
        }
    }

    public Asiento buscarAsiento(int numero) {
        // Devuelve el asiento solicitado o null si no existe.
        for (Asiento asiento : asientos) {
            if (asiento.getNumero() == numero) {
                return asiento;
            }
        }
        return null;
    }
}
