// Contiene la informacion basica del pago de una reserva.
public class Pago {
    // Metodo elegido por el pasajero para realizar el pago.
    private final String metodo;
    // Monto total que corresponde al precio del vuelo.
    private final double monto;

    public Pago(String metodo, double monto) {
        this.metodo = metodo;
        this.monto = monto;
    }

    public boolean procesar() {
        // Esta simulacion acepta pagos con metodo informado y monto positivo.
        return !metodo.trim().isEmpty() && monto > 0;
    }

    public String getMetodo() {
        return metodo;
    }

    public double getMonto() {
        return monto;
    }

}
