// Guarda los datos personales asociados a una reserva.
public class Pasajero {
    // Los campos son finales porque representan datos que no deben modificarse.
    private final String nombre;
    private final String documento;
    private final String correo;

    public Pasajero(String nombre, String documento, String correo) {
        this.nombre = nombre;
        this.documento = documento;
        this.correo = correo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDocumento() {
        return documento;
    }

    public String getCorreo() {
        return correo;
    }
}
