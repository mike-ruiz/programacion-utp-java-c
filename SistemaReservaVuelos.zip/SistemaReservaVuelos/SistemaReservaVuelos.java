import java.util.Scanner;

// Clase principal: coordina el menu, los vuelos y las reservas del sistema.
public class SistemaReservaVuelos {
    // Scanner compartido para leer todas las respuestas escritas por el usuario.
    private final Scanner entrada = new Scanner(System.in);

    // Arreglos fijos: almacenan como maximo 100 objetos de cada tipo.
    private final Vuelo[] vuelos = new Vuelo[100];
    private final Reserva[] reservas = new Reserva[100];

    // Indican cuantos elementos validos existen dentro de cada arreglo.
    private int cantidadVuelos = 0;
    private int cantidadReservas = 0;

    // Sirve para generar codigos consecutivos de reserva, por ejemplo R001.
    private int siguienteCodigo = 1;

    public static void main(String[] args) {
        // Crea una instancia del sistema y ejecuta su metodo principal.
        new SistemaReservaVuelos().iniciar();
    }

    public void iniciar() {
        int opcion;
        do {
            mostrarMenu();
            opcion = leerEntero("Selecciona una opcion: ");

            // El switch decide que accion ejecutar segun el numero ingresado.
            switch (opcion) {
                case 1:
                    mostrarVuelos();
                    break;
                case 2:
                    crearReserva();
                    break;
                case 3:
                    mostrarReservas();
                    break;
                case 4:
                    registrarVuelo();
                    break;
                case 5:
                    System.out.println("Gracias por usar el sistema.");
                    break;
                default:
                    System.out.println("Opcion no valida. Intenta nuevamente.");
            }
        } while (opcion != 5);
    }

    private void mostrarMenu() {
        // Las opciones se muestran antes de leer la seleccion del usuario.
        System.out.println("\n=== SISTEMA DE RESERVA DE VUELOS ===");
        System.out.println("1. Ver vuelos");
        System.out.println("2. Reservar un vuelo");
        System.out.println("3. Ver reservas");
        System.out.println("4. Registrar vuelo");
        System.out.println("5. Salir");
    }

    private void mostrarVuelos() {
        // Evita recorrer el arreglo si aun no se ha registrado ningun vuelo.
        if (cantidadVuelos == 0) {
            System.out.println("\nTodavia no hay vuelos registrados.");
            return;
        }

        System.out.println("\nVuelos disponibles:");
        // Solo se recorren las posiciones ocupadas, no las 100 posiciones vacias.
        for (int i = 0; i < cantidadVuelos; i++) {
            vuelos[i].mostrarInformacion();
        }
    }

    private void registrarVuelo() {
        // Comprueba que exista espacio en el arreglo antes de agregar datos.
        if (cantidadVuelos == vuelos.length) {
            System.out.println("No se pueden registrar mas vuelos.");
            return;
        }

        System.out.println("\n--- Registrar vuelo ---");
        String codigo = leerTexto("Codigo del vuelo: ");
        // No permite dos vuelos con el mismo codigo.
        if (buscarVuelo(codigo) != null) {
            System.out.println("Ya existe un vuelo con ese codigo.");
            return;
        }

        // Se reciben los datos y se convierten a los tipos necesarios.
        String origen = leerTexto("Origen: ");
        String destino = leerTexto("Destino: ");
        String fecha = leerTexto("Fecha (AAAA-MM-DD): ");
        String hora = leerTexto("Hora (HH:MM): ");
        double precio = leerDecimal("Precio: ");
        int cantidadAsientos = leerEntero("Cantidad de asientos: ");

        // La validacion evita guardar textos vacios o valores negativos o cero.
        if (codigo.isEmpty() || origen.isEmpty() || destino.isEmpty()
                || fecha.isEmpty() || hora.isEmpty() || precio <= 0
                || cantidadAsientos <= 0) {
            System.out.println("Todos los datos deben ser validos.");
            return;
        }

        // Se crea el objeto Vuelo y se guarda en la siguiente posicion libre.
        vuelos[cantidadVuelos++] = new Vuelo(
                codigo, origen, destino, fecha, hora, precio, cantidadAsientos);
        System.out.println("Vuelo registrado correctamente.");
    }

    private void crearReserva() {
        // Comprueba el limite del arreglo antes de iniciar una reserva.
        if (cantidadReservas == reservas.length) {
            System.out.println("No hay espacio para mas reservas.");
            return;
        }

        mostrarVuelos();
        // Convierte el codigo escrito por el usuario en un objeto Vuelo existente.
        Vuelo vuelo = buscarVuelo(leerTexto("Escribe el codigo del vuelo: "));
        if (vuelo == null) {
            System.out.println("Vuelo no encontrado.");
            return;
        }

        vuelo.mostrarAsientos();
        int numeroAsiento = leerEntero("Selecciona un asiento disponible: ");
        // Buscar el asiento permite distinguir uno inexistente de uno ocupado.
        Asiento asiento = vuelo.buscarAsiento(numeroAsiento);
        if (asiento == null || !asiento.estaDisponible()) {
            System.out.println("Asiento no disponible.");
            return;
        }

        // Se solicita la informacion del pasajero y el metodo de pago.
        String nombre = leerTexto("Nombre del pasajero: ");
        String documento = leerTexto("Documento: ");
        String correo = leerTexto("Correo electronico: ");
        String metodoPago = leerTexto("Metodo de pago (tarjeta/efectivo): ");

        Pago pago = new Pago(metodoPago, vuelo.getPrecio());
        // La reserva se cancela si el pago no cumple las reglas simuladas.
        if (!pago.procesar()) {
            System.out.println("Pago no valido.");
            return;
        }

        // Esta segunda comprobacion ayuda a evitar reservar un asiento ocupado.
        if (!asiento.reservar()) {
            System.out.println("El asiento ya esta ocupado.");
            return;
        }

        Pasajero pasajero = new Pasajero(nombre, documento, correo);
        // String.format agrega ceros: R1 se convierte en R001.
        String codigo = String.format("R%03d", siguienteCodigo++);
        Reserva reserva = new Reserva(codigo, pasajero, vuelo, asiento, pago);
        reservas[cantidadReservas++] = reserva;

        // Se genera y muestra el ticket cuando todos los pasos se completan.
        Ticket ticket = new Ticket("T" + codigo.substring(1), reserva);
        System.out.println("Reserva confirmada. Pago aprobado (simulacion).");
        ticket.imprimir();
    }

    private Vuelo buscarVuelo(String codigo) {
        // Recorre solo los vuelos registrados y compara codigos sin distinguir mayusculas.
        for (int i = 0; i < cantidadVuelos; i++) {
            if (vuelos[i].getCodigo().equalsIgnoreCase(codigo.trim())) {
                return vuelos[i];
            }
        }
        return null;
    }

    private void mostrarReservas() {
        // Si el contador es cero, todavia no hay reservas almacenadas.
        if (cantidadReservas == 0) {
            System.out.println("Todavia no hay reservas.");
            return;
        }

        System.out.println("\nReservas registradas:");
        // Recorre las reservas ocupadas y obtiene sus datos relacionados.
        for (int i = 0; i < cantidadReservas; i++) {
            Reserva reserva = reservas[i];
            System.out.printf("%s | %s | Vuelo %s | Asiento %d | $%.2f%n",
                    reserva.getCodigo(),
                    reserva.getPasajero().getNombre(),
                    reserva.getVuelo().getCodigo(),
                    reserva.getAsiento().getNumero(),
                    reserva.getPago().getMonto());
        }
    }

    private String leerTexto(String mensaje) {
        // Imprime la pregunta y elimina espacios al inicio y al final.
        System.out.print(mensaje);
        return entrada.nextLine().trim();
    }

    private int leerEntero(String mensaje) {
        // El bucle se repite hasta que el usuario ingrese un entero valido.
        while (true) {
            System.out.print(mensaje);
            String texto = entrada.nextLine().trim();
            try {
                return Integer.parseInt(texto);
            } catch (NumberFormatException excepcion) {
                System.out.println("Ingresa un numero entero valido.");
            }
        }
    }

    private double leerDecimal(String mensaje) {
        // Repite la lectura hasta que el texto pueda convertirse a decimal.
        while (true) {
            System.out.print(mensaje);
            String texto = entrada.nextLine().trim();
            try {
                return Double.parseDouble(texto);
            } catch (NumberFormatException excepcion) {
                System.out.println("Ingresa un precio valido.");
            }
        }
    }
}
