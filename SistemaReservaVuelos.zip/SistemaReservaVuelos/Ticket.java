// Representa el comprobante imprimible de una reserva confirmada.
public class Ticket {
    // Codigo identificador separado del codigo de la reserva.
    private final String codigo;
    private final Reserva reserva;

    public Ticket(String codigo, Reserva reserva) {
        this.codigo = codigo;
        this.reserva = reserva;
    }

    public void imprimir() {
        // Se obtiene el vuelo una sola vez para mostrar sus datos.
        Vuelo vuelo = reserva.getVuelo();
        System.out.println("\n========== TICKET ==========");
        System.out.println("Ticket: " + codigo);
        System.out.println("Reserva: " + reserva.getCodigo());
        System.out.println("Pasajero: " + reserva.getPasajero().getNombre());
        System.out.println("Documento: " + reserva.getPasajero().getDocumento());
        System.out.println("Vuelo: " + vuelo.getCodigo() + " | "
                + vuelo.getOrigen() + " - " + vuelo.getDestino());
        System.out.println("Fecha y hora: " + vuelo.getFecha() + " " + vuelo.getHora());
        System.out.println("Asiento: " + reserva.getAsiento().getNumero());
        System.out.printf("Pago: $%.2f con %s%n",
                reserva.getPago().getMonto(), reserva.getPago().getMetodo());
        System.out.println("============================\n");
    }
}
