// Une al pasajero, el vuelo, el asiento y el pago en una reserva.
public class Reserva {
    // Codigo unico generado por el sistema, por ejemplo R001.
    private final String codigo;
    private final Pasajero pasajero;
    private final Vuelo vuelo;
    private final Asiento asiento;
    private final Pago pago;

    public Reserva(String codigo, Pasajero pasajero, Vuelo vuelo,
                   Asiento asiento, Pago pago) {
        this.codigo = codigo;
        this.pasajero = pasajero;
        this.vuelo = vuelo;
        this.asiento = asiento;
        this.pago = pago;
    }

    public String getCodigo() {
        return codigo;
    }

    public Pasajero getPasajero() {
        return pasajero;
    }

    public Vuelo getVuelo() {
        return vuelo;
    }

    public Asiento getAsiento() {
        return asiento;
    }

    public Pago getPago() {
        return pago;
    }
}
