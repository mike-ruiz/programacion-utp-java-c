// Representa un asiento individual dentro de un vuelo.
public class Asiento {
    // El numero identifica la posicion del asiento; final evita que cambie.
    private final int numero;
    // Indica si el asiento puede ser reservado o ya esta ocupado.
    private boolean disponible;

    public Asiento(int numero) {
        this.numero = numero;
        // Al crearse, todos los asientos comienzan disponibles.
        this.disponible = true;
    }

    public int getNumero() {
        return numero;
    }

    public boolean estaDisponible() {
        return disponible;
    }

    public boolean reservar() {
        // Rechaza la reserva si otro pasajero ya ocupo el asiento.
        if (!disponible) {
            return false;
        }
        // Cambia el estado y confirma que la reserva fue exitosa.
        disponible = false;
        return true;
    }

}
