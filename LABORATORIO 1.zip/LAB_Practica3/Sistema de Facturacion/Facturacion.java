import java.util.Locale;
import java.util.Scanner;

public class Facturacion {
    private static final double ITBMS = 0.07;
    private static final double Descuento = 0.10;

    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        
        try (Scanner scanner = new Scanner(System.in)) {
            double subtotalCompra = 0;

            System.out.println("====================================");
            System.out.println("       SISTEMA DE FACTURACION");
            System.out.println("====================================");

            // Se solicitan 3 productos para construir la factura.
            for (int i = 1; i <= 3; i++) {
                // Se solicita el nombre del producto y se guarda en una variable.
                System.out.print("Ingrese el nombre del producto " + i + ": ");
                String Nombreproducto = scanner.nextLine();

                // Se solicita la cantidad vendida del producto.
                System.out.print("Ingrese la cantidad del producto " + i + ": ");
                int cantidad = scanner.nextInt();

                // Se solicita el precio unitario del producto.
                System.out.print("Ingrese el precio unitario del producto " + i + ": B/. ");
                double precioUnitario = scanner.nextDouble();

                // Se calculan los ingresos del producto y se acumulan al subtotal.
                double subtotalProducto = cantidad * precioUnitario;
                subtotalCompra = subtotalCompra + subtotalProducto;

                System.out.printf("Subtotal del producto %d (%s): B/. %.2f%n", i, Nombreproducto, subtotalProducto);
                System.out.println();

                // Se limpia el salto de línea para continuar con la siguiente lectura.
                scanner.nextLine();
            }

            // Se calcula el impuesto del 7% sobre el subtotal.
            double itbms = subtotalCompra * ITBMS;
            // Se calcula el descuento del 10% sobre el subtotal.
            double descuento = subtotalCompra * Descuento;
            // Se obtiene el total final restando el descuento y sumando el impuesto.
            double totalPagar = subtotalCompra + itbms - descuento;

            // Se muestran los resultados finales de la factura.
            System.out.println("====================================");
            System.out.printf("Subtotal de la compra: B/. %.2f%n", subtotalCompra);
            System.out.printf("ITBMS (7%%): B/. %.2f%n", itbms);
            System.out.printf("Descuento (10%%): B/. %.2f%n", descuento);
            System.out.printf("Total a pagar: B/. %.2f%n", totalPagar);
            System.out.println("====================================");
        }
    }
}
