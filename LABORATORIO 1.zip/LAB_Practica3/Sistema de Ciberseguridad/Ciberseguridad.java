import java.util.Scanner;

public class Ciberseguridad {
    private static final int Minimos_de_Caracteres = 8;

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("====================================");
            System.out.println("    VALIDACION DE CONTRASENA");
            System.out.println("====================================");

            // Se solicita la contraseña por teclado.
            System.out.print("Ingrese la contraseña: ");
            String contraseña = scanner.nextLine();

            // Se muestra la contraseña ingresada para verla en pantalla.
            System.out.println("La contraseña ingresada es: " + contraseña);

            // Se compara la longitud de la contraseña con la mínima requerida.
            if (contraseña.length() >= Minimos_de_Caracteres) {
                System.out.println("La contraseña cumple con la longitud mínima requerida.");
            } else {
                System.out.println("La contraseña NO cumple con la longitud mínima requerida.");
            }
        }
    }
}
