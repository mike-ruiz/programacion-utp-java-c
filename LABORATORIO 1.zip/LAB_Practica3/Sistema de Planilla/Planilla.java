import java.util.Locale;
import java.util.Scanner;

public class Planilla {
    // Se define la tarifa por hora, el porcentaje para cada descuento y la regla de redondeo.
    private static final double Tarifa_Por_Hora = 5.30;
    private static final double Seguro_Social = 0.0975;
    private static final double Seguro_Educativo = 0.0125;

    public static void main(String[] args) {
        // Se usa el punto decimal en formato internacional para manejar números con decimales.
        Locale.setDefault(Locale.US);

        try (Scanner scanner = new Scanner(System.in)) {
            // Se muestra el encabezado del sistema.
            System.out.println("=== Sistema de Planilla Quincenal ===");

            // Se solicita el nombre del trabajador y se valida que no venga vacío.
            System.out.print("Ingrese el nombre del trabajador: ");
            String nombre = scanner.nextLine().trim();
            if (nombre.isEmpty()) {
                System.out.println("El nombre del trabajador no puede estar vacío.");
                return;
            }

            // Se solicita la cantidad de horas trabajadas en la quincena.
            System.out.print("Ingrese las horas trabajadas en la quincena: ");
            if (!scanner.hasNextDouble()) {
                System.out.println("Debe ingresar una cantidad válida de horas.");
                return;
            }

            double horasTrabajadas = scanner.nextDouble();
            if (horasTrabajadas < 0) {
                System.out.println("Las horas trabajadas no pueden ser negativas.");
                return;
            }

            // Se calculan el salario bruto y las deducciones aplicadas.
            double sueldoBruto = redondear(horasTrabajadas * Tarifa_Por_Hora);
            double deduccionSeguroSocial = redondear(sueldoBruto * Seguro_Social);
            double deduccionSeguroEducativo = redondear(sueldoBruto * Seguro_Educativo);
            double totalDeducciones = redondear(deduccionSeguroSocial + deduccionSeguroEducativo);
            double sueldoNeto = redondear(sueldoBruto - totalDeducciones);

            // Se imprimen los resultados finales para que el usuario vea el cálculo completo.
            System.out.println();
            System.out.println("=== Resultados de la Planilla Quincenal ===");
            System.out.println("Nombre del empleado: " + nombre);
            System.out.printf("Horas trabajadas: %.2f%n", horasTrabajadas);
            System.out.printf("Sueldo bruto: B/. %.2f%n", sueldoBruto);
            System.out.printf("Seguro social (9.75%%): B/. %.2f%n", deduccionSeguroSocial);
            System.out.printf("Seguro educativo (1.25%%): B/. %.2f%n", deduccionSeguroEducativo);
            System.out.printf("Total de deducciones: B/. %.2f%n", totalDeducciones);
            System.out.printf("Sueldo neto: B/. %.2f%n", sueldoNeto);
        }
    }

    // Método auxiliar para evitar errores al mostrar valores monetarios.
    private static double redondear(double cantidad) {
        return Math.round(cantidad * 100.0) / 100.0;
    }
}