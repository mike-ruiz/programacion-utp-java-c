import java.util.Scanner;

public class Ventas {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        // Se muestra el encabezado del sistema de ventas.
        System.out.println("        TECNOLOGY S.A.");
        System.out.println("VENTAS DE EQUIPOS DE TECNOLOGIA");
        System.out.println("      SISTEMA DE VENTAS");
        System.out.println();

        // Se solicita al usuario que ingrese las ventas de la sucursal de Chiriquí para los meses de abril, mayo y junio.
        System.out.print("Ventas de Chiriqui en Abril: ");
        double chiriquiAbril = teclado.nextDouble();
        System.out.print("Ventas de Chiriqui en Mayo: ");
        double chiriquiMayo = teclado.nextDouble();
        System.out.print("Ventas de Chiriqui en Junio: ");
        double chiriquiJunio = teclado.nextDouble();

        // Se solicita al usuario que ingrese las ventas de la sucursal de Panamá para los meses de abril, mayo y junio.
        System.out.print("Ventas de Panama en Abril: ");
        double panamaAbril = teclado.nextDouble();
        System.out.print("Ventas de Panama en Mayo: ");
        double panamaMayo = teclado.nextDouble();
        System.out.print("Ventas de Panama en Junio: ");
        double panamaJunio = teclado.nextDouble();

        // Se solicita al usuario que ingrese las ventas de la sucursal de Coclé para los meses de abril, mayo y junio.
        System.out.print("Ventas de Cocle en Abril: ");
        double cocleAbril = teclado.nextDouble();
        System.out.print("Ventas de Cocle en Mayo: ");
        double cocleMayo = teclado.nextDouble();
        System.out.print("Ventas de Cocle en Junio: ");
        double cocleJunio = teclado.nextDouble();

        // Se calculan los totales por sucursal.
        double totalChiriqui = chiriquiAbril + chiriquiMayo + chiriquiJunio;
        double totalPanama = panamaAbril + panamaMayo + panamaJunio;
        double totalCocle = cocleAbril + cocleMayo + cocleJunio;

        // Se calculan los totales por mes y el total del trimestre.
        double totalAbril = chiriquiAbril + panamaAbril + cocleAbril;
        double totalMayo = chiriquiMayo + panamaMayo + cocleMayo;
        double totalJunio = chiriquiJunio + panamaJunio + cocleJunio;
        double totalTrimestre = totalAbril + totalMayo + totalJunio;

        // Se muestra el resumen de ventas por sucursal y por mes.
        System.out.println();
        System.out.println("          RESUMEN DE VENTAS");
        System.out.println("Sucursal | Abril | Mayo | Junio | Total");
        System.out.println("Chiriqui | " + chiriquiAbril + " | " + chiriquiMayo + " | " + chiriquiJunio + " | " + totalChiriqui);
        System.out.println("Panama   | " + panamaAbril + " | " + panamaMayo + " | " + panamaJunio + " | " + totalPanama);
        System.out.println("Cocle    | " + cocleAbril + " | " + cocleMayo + " | " + cocleJunio + " | " + totalCocle);
        System.out.println("Total    | " + totalAbril + " | " + totalMayo + " | " + totalJunio + " | " + totalTrimestre);

        teclado.close();
    }
}
