import java.util.Scanner;// Importa la clase Scanner para leer datos desde el teclado

public class Dispositivo {// Declara la clase pública Dispositivo


    // 1. Atributos
    String nombre;                      // Almacena el nombre del dispositivo
    String direccionIP;                 // Almacena la dirección IP del dispositivo
    String tipo;                        // Almacena el tipo de dispositivo


    // 2. Constructor
    public Dispositivo() {// Constructor vacío
    }// Fin del constructor


    // 3. Método para ingresar los datos (con validaciones y control de flujo)
    public void ingresarDatos(Scanner teclado) {// Recibe el Scanner para reutilizarlo

        System.out.println("\nREGISTRO DE DISPOSITIVOS DE RED"); // Título con salto previo

        // --- Validación con WHILE: no permite nombre vacío ---
        do {// Repite hasta que el nombre sea válido

            System.out.print("Ingrese el nombre del dispositivo: ");
            nombre = teclado.nextLine().trim();// Lee y quita espacios extremos

            if (nombre.isEmpty()) {// SELECTIVA: verifica si está vacío
                System.out.println("⚠ El nombre no puede estar vacío. Intente de nuevo.");
            }// Fin del if

        } while (nombre.isEmpty());// REPETITIVA: repite mientras esté vacío

        // --- Validación con WHILE: la IP debe tener formato x.x.x.x ---
        boolean ipValida = false;// Bandera de control

        while (!ipValida) {// REPETITIVA: sigue hasta que sea válida

            System.out.print("Ingrese la direccion IP (formato x.x.x.x): ");
            direccionIP = teclado.nextLine().trim();// Lee la IP

            ipValida = esIPValida(direccionIP);// Llama al método validador

            if (!ipValida) {// SELECTIVA: si no es válida
                System.out.println("⚠ IP inválida. Debe tener 4 bloques entre 0 y 255.");
            }// Fin del if

        }// Fin del while

        // --- Selección con SWITCH: tipo de dispositivo ---
        int opcion = 0;// Variable para la opción elegida

        do {// REPETITIVA: repite hasta opción válida

            System.out.println("\nSeleccione el tipo de dispositivo:");
            System.out.println("1. Router");
            System.out.println("2. Switch");
            System.out.println("3. Servidor");
            System.out.println("4. PC");
            System.out.println("5. Firewall");

            System.out.print("Opción (1-5): ");

            try {// Manejo de errores al convertir a número
                opcion = Integer.parseInt(teclado.nextLine().trim());
            } catch (NumberFormatException e) {// Si el usuario escribe letras
                opcion = 0;// Fuerza opción inválida
            }

            switch (opcion) {// SELECTIVA múltiple: asigna según la opción

                case 1 -> tipo = "Router";// Opción 1
                case 2 -> tipo = "Switch";// Opción 2
                case 3 -> tipo = "Servidor";// Opción 3
                case 4 -> tipo = "PC";// Opción 4
                case 5 -> tipo = "Firewall";// Opción 5

                default -> {// Ninguna opción válida
                    System.out.println("⚠ Opción inválida. Elija entre 1 y 5.");
                    tipo = null;// Marca como null para repetir
                }
            } // Fin del switch

        } while (tipo == null);// REPETITIVA: repite mientras tipo sea null

        System.out.println("✔ Dispositivo ingresado correctamente.");

    } // Fin del método ingresarDatos



    // 4. Método para mostrar los datos (con FOR para decorar)
    public void mostrarDatos(int indice) {  // Recibe el número del dispositivo

        System.out.println("\n===== DATOS DEL DISPOSITIVO #" + indice + " =====");
        System.out.println("Nombre:              " + nombre);
        System.out.println("Direccion IP: " + direccionIP);
        System.out.println("Tipo:             " + tipo);

        // --- FOR: imprime línea decorativa con 33 '=' ---
        for (int i = 0; i < 33; i++) {// REPETITIVA: ejecuta 33 veces
            System.out.print("=");// Imprime un '=' sin salto
        }

        System.out.println();// Salto de línea final

    } // Fin del método mostrarDatos



    // 5. Método auxiliar: valida la IP (usa SELECTIVA y FOR)
    private boolean esIPValida(String ip) {// Devuelve true si la IP tiene formato correcto

        String[] partes = ip.split("\\.");// Separa la IP por puntos

        if (partes.length != 4) {// SELECTIVA: debe tener 4 partes
            return false;// Si no, inválida
        }

        for (String p : partes) {// REPETITIVA: recorre cada parte

            try { // Intenta convertir a número
                int n = Integer.parseInt(p);// Convierte la parte a entero

                if (n < 0 || n > 255) {// SELECTIVA: rango válido 0-255
                    return false;// Fuera de rango -> inválida
                }

            } catch (NumberFormatException e) {// Si no es número
                return false;// Inválida
            }
        }

        return true;// Todas las partes válidas

    } // Fin del método esIPValida



    // 6. Método principal (menú con DO-WHILE y SWITCH)
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);// Scanner compartido para todo el programa

        int opcionMenu;//Variable para la opción del menú

        do {// REPETITIVA: menú hasta que el usuario salga

            System.out.println("\n===== MENÚ PRINCIPAL =====");
            System.out.println("1. Registrar un dispositivo");
            System.out.println("2. Salir");
            System.out.print("Opción: ");

            try {// Manejo de errores
                opcionMenu = Integer.parseInt(teclado.nextLine().trim());
            } catch (NumberFormatException e) {  // Si escribe letras
                opcionMenu = 0;// Fuerza opción inválida
            }

            switch (opcionMenu) {// Selectivca múltiple: ejecuta según la opción

                case 1 -> {// Registrar dispositivo
                    Dispositivo equipo1 = new Dispositivo();//Crea el objeto
                    equipo1.ingresarDatos(teclado);// Pide los datos
                    equipo1.mostrarDatos(1);// Muestra los datos
                }

                case 2 -> System.out.println("      Saliendo del programa...");// Salir

                default -> System.out.println("⚠ Opción inválida. Intente de nuevo.");
            } // Fin del switch

        } while (opcionMenu != 2);// REPETITIVA: sigue mientras no sea 2

        teclado.close();// Cierra el Scanner al finalizar

    } // Fin del método main

} // Fin de la clase Dispositivo