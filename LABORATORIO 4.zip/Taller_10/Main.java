import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double suma = 0;
        double mayor = 0;
        double menor = 0;
        int aprobadas = 0;

        for (int i = 1; i <= 10; i++) {
            System.out.print("Ingrese la nota " + i + ": ");
            double nota = scanner.nextDouble();

            suma += nota;

            if (i == 1) {
                mayor = nota;
                menor = nota;
            } else {
                if (nota > mayor) {
                    mayor = nota;
                }
                if (nota < menor) {
                    menor = nota;
                }
            }

            if (nota >= 71) {
                aprobadas++;
            }
        }

        double promedio = suma / 10;

        System.out.println("\nPromedio: " + promedio);
        System.out.println("Nota mas alta: " + mayor);
        System.out.println("Nota mas baja: " + menor);
        System.out.println("Cantidad de aprobadas: " + aprobadas);

        scanner.close();
    }
}
