import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese el primer número: ");
        int N1 = sc.nextInt();

        System.out.print("Ingrese el segundo número: ");
        int N2 = sc.nextInt();

        System.out.print("Ingrese el tercer número: ");
        int N3 = sc.nextInt();

        int mayor;

        if (N1 >= N2 && N1 >= N3) {
            mayor = N1;
        } else if (N2 >= N1 && N2 >= N3) {
            mayor = N2;
        } else {
            mayor = N3;
        }

        System.out.println("\nEl número mayor es: " + mayor);

        sc.close();
    }
}